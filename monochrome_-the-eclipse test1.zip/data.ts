// This file has been split into multiple data-centric files (dataCharacters.ts, dataMonsters.ts, etc.)
// for better organization and maintainability. This file is no longer in use.
