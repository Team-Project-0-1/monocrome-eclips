export const stageData = {
  1: {
    name: "벙커 외곽",
    description: "폐허가 된 도시의 변두리",
    theme: "돌연변이와 약탈자",
    combatPool: ["marauder1", "marauder2", "infectedDog"],
    miniboss: "marauderLeader",
    boss: "lumenReaper",
    eventPool: ["event_supplies", "event_survivor", "event_trap"],
    shopType: "basic",
  },
};
